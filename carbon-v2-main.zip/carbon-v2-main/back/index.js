require("dotenv").config();
const express = require('express');
const app = express();
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require("crypto");

const jsonPath = path.join(__dirname, '.', 'db', 'banco-dados-usuario.json');
const jsonPathSaldo = path.join(__dirname, '.', 'db', 'banco-dados-saldos.json');
const jsonPathHistorico = path.join(__dirname, '.', 'db', 'banco-dados-historico.json');

/** Sync */
function randomStringAsBase64Url(size) {
  return crypto.randomBytes(size).toString("base64url");
}

function getDadosBancoUsuario() {
    return JSON.parse(fs.readFileSync(jsonPath, { encoding: 'utf8', flag: 'r' }));
}

function getDadosBancoSaldo() {
    return JSON.parse(fs.readFileSync(jsonPathSaldo, { encoding: 'utf8', flag: 'r' }));
}

function getDadosBancoHistorico() {
    return JSON.parse(fs.readFileSync(jsonPathHistorico, { encoding: 'utf8', flag: 'r' }));
}

//usuário logado
let _user;

//Necessário para extrair os dados de Forms vindos de uma requisição POST
app.use(express.json());
app.use(cors());

app.listen(3000, () => {
    console.log('Servidor na porta 3000');
});

const User = require('./model/User');
const Saldo = require('./model/Saldo');
const Transacao = require('./model/Transacao');


//Requisicao com POST publica para autenticar usuário
app.post('/login', async (req,res) => {

    //extraindo os dados do formulário para criacao do usuario
    const {email, password} = req.body; 
    
    //Abre o bd (aqui estamos simulando com arquivo)
    const usuariosCadastrados = getDadosBancoUsuario();

    //verifica se existe usuario com email   
    for (let user of usuariosCadastrados){
        if(user.email === email){
            const passwordValidado = await bcrypt.compare(password, user.password);
            if(passwordValidado){ 
                
                const token = jwt.sign(user, process.env.TOKEN);
                _user = user;

                return res.json({ "token" : token});
            }
            
            else
                return res.status(422).send(`Usuario ou senhas incorretas.`);
        }   
    }
    //Nesse ponto não existe usuario com email informado.
    return res.status(409).send(`Usuario com email ${email} não existe. Considere criar uma conta!`);

})

// Requisicao com POST publica para autenticar codigo de recuperacao
// e permitir recuperar e alterar senha
app.post('/recuperar', async (req,res) => {

    //extraindo os dados do formulário para criacao do usuario
    const {token, email, password} = req.body; 
    
    //Abre o bd (aqui estamos simulando com arquivo)
    const usuariosCadastrados = getDadosBancoUsuario();

    // Verifica se existe usuário com o último email armazenado
    for (let user of usuariosCadastrados){
        if(user.email === email){

            if(user.token === token) {
                // Atualiza a senha do usuário com a nova senha
                const salt = await bcrypt.genSalt(10);
                const novaSenhaCrypt = await bcrypt.hash(password, salt);
                user.password = novaSenhaCrypt;

                // Altera o token 
                user.token = randomStringAsBase64Url(11);
            
                // Salva as alterações no "banco"
                fs.writeFileSync(jsonPath, JSON.stringify(usuariosCadastrados, null, 2));
            
                return res.send('Senha alterada com sucesso!');
            }
        } 
    }

    // Usuário não encontrado
    return res.status(409).send(`Usuário não encontrado ou informação incorreta.`);

})

// Requisicao com PUT para autenticar codigo de recuperacao
// e permitir a alteração do email
app.put('/email', async (req,res) => {

    //extraindo os dados do formulário para criacao do usuario
    const {token, email, novoEmail, password} = req.body; 

    //Abre o bd (aqui estamos simulando com arquivo)
    const usuariosCadastrados = getDadosBancoUsuario();
    const saldosCadastrados = getDadosBancoSaldo();

    for (let users of usuariosCadastrados){
        if(users.email === novoEmail){
            // Email ja utilizado. Impossivel alterar
            // Retornando o erro 409 para indicar conflito
            return res.status(409).send(`Usuario com email ${novoEmail} já existe.`);
        }
    }

    // Verifica se existe usuário com o último email armazenado
    for (let users of usuariosCadastrados){
        if(users.email === email){
            const passwordValidado = await bcrypt.compare(password, users.password);
            if(passwordValidado){
                if(users.token === token) {
                    // Atualiza o email do usuario com o novoEmail
                    users.email = novoEmail;
    
                    // Altera o token 
                    users.token = randomStringAsBase64Url(11);
                
                    // precisa alterar o email do saldo tambem
                    for (let emailSaldo of saldosCadastrados){
                        if(emailSaldo.email === email){

                            emailSaldo.email = novoEmail;
                        }
                    }

                    // Salva as alterações no "banco"
                    fs.writeFileSync(jsonPath, JSON.stringify(usuariosCadastrados, null, 2));
                    fs.writeFileSync(jsonPathSaldo,JSON.stringify(saldosCadastrados,null,2));

                    return res.send('Email alterado com sucesso!');
                }
            }
        } 
    }

    // Usuário não encontrado
    return res.status(409).send(`Usuário não encontrado ou informação incorreta.`);

})

//Requisicao com POST publica para criar usuário
app.post('/create', async (req,res) => {
    //extraindo os dados do formulário para criacao do usuario
    const {username, email, password} = req.body; 
    
    const usuariosCadastrados = getDadosBancoUsuario();
    const saldosCadastrados = getDadosBancoSaldo();

    //verifica se já existe usuario com o email informado
    
    for (let users of usuariosCadastrados){
        if(users.email === email){
            //usuario já existe. Impossivel criar outro
            //Retornando o erro 409 para indicar conflito
            return res.status(409).send(`Usuario com email ${email} já existe.`);
        }   
    }
    //Deu certo. Vamos colocar o usuário no "banco"
    //Gerar um id incremental baseado na qt de users
    const id = usuariosCadastrados.length + 1;
    
    //gera um token único para cada usuário
    const token = randomStringAsBase64Url(11);

    //gerar uma senha cryptografada
    const salt = await bcrypt.genSalt(10);
    const passwordCrypt = await bcrypt.hash(password,salt);

    //Criacao do user
    const user = new User(id, username, email, passwordCrypt, token);
    const saldo = new Saldo(email,0);

    //Salva user e saldo no banco
    usuariosCadastrados.push(user);
    saldosCadastrados.push(saldo);

    fs.writeFileSync(jsonPathSaldo,JSON.stringify(saldosCadastrados,null,2));
    fs.writeFileSync(jsonPath,JSON.stringify(usuariosCadastrados,null,2));
    res.send(`Tudo certo usuario criado com sucesso.`);
});

// gambiarra aqui, deve ter uma forma mais inteligente
app.get('/verificador', verificaToken,  (req, res) => {

    const verificado = true;
    return res.json(verificado);

})

// Endpoint para obter informações de configurações com base no email do usuário
app.get('/configuracoes/:email', (req, res) => {
    const email = req.params.email;
  

    const usuariosCadastrados = getDadosBancoUsuario();
    const saldosCadastrados = getDadosBancoSaldo();

    //verifica se já existe usuario com o email informado
    
    for (let users of usuariosCadastrados){
        if(users.email === email){

            for(let userSaldo of saldosCadastrados) {
                if(userSaldo.email === email) {
                    const usuarioConfiguracoes = {
                        token: users.token,
                        username: users.username,
                        email: users.email,
                        saldo: userSaldo.saldo
                    };
        
                    res.json(usuarioConfiguracoes);
                }
            }
            
        }  
    }

});


app.get('/historico', verificaToken,  (req, res) => {

    const historicos = getDadosBancoHistorico();
    let historicoUsuario = historicos.filter(historico => historico.emailEnvio === _user.email);
    return res.json(historicoUsuario);

})

app.delete('/deletar', (req, res) => {
    
    const usuariosCadastrados = getDadosBancoUsuario();
    const usuarioIndex = usuariosCadastrados.findIndex((usuario) => usuario.email === _user.email);

    const historicos = getDadosBancoHistorico();
    let historicoUsuario = historicos.filter(historico => historico.emailEnvio === _user.email)

    if(historicoUsuario && historicoUsuario.length == 0 && _user.saldo == 0) {
        usuariosCadastrados.splice(usuarioIndex,1);
        fs.writeFileSync(jsonPath, JSON.stringify(usuariosCadastrados, null, 2));
        res.json({ message: 'Usuário excluído com sucesso.' });
    } else {
        res.status(403).json({ error: "Você não pode excluir sua conta porque existe saldo ou um histórico de transação nela."})
    }
});


app.put('/transacao', async (req,res) => {

    const {emailRecebe, quantidade} = req.body;

    if(_user && _user.saldo == 0){
        res.status(403).json({ error: "Você não tem saldo para realizar uma transação."})
    } else if(_user && _user.saldo < quantidade) {
        res.status(400).json({error:"Quantia insuficiente em seu saldo"})
    } else {

        const usuariosCadastrados = getDadosBancoUsuario();
        const saldosCadastrados = getDadosBancoSaldo();
        const historicosCadastrados = getDadosBancoHistorico();

        for (let users of usuariosCadastrados){
            if(users.email === _user.email){
                users.saldo -= quantidade;
            }
        }

        for (let users of usuariosCadastrados){
            if(users.email === emailRecebe){
                users.saldo += quantidade;
            }
        }

        const token = randomStringAsBase64Url(20);
        const transacao = new Transacao(token,_user.email, emailRecebe, quantidade );

        historicosCadastrados.push(transacao);

        fs.writeFileSync(jsonPath, JSON.stringify(usuariosCadastrados, null, 2));
        fs.writeFileSync(jsonPathSaldo,JSON.stringify(saldosCadastrados,null,2));
        fs.writeFileSync(jsonPathHistorico,JSON.stringify(historicosCadastrados,null,2));


    }
    


})

app.put('/depositar', async (req,res) => {

    //extraindo os dados do formulário para criacao do usuario
    const {quantidade} = req.body; 

    //Abre o bd (aqui estamos simulando com arquivo)
    const saldosCadastrados = getDadosBancoSaldo();

    // Verifica se existe usuário com o último email armazenado
    for (let saldos of saldosCadastrados) {
        if(saldos.email === _user.email) {
            saldos.saldo += quantidade
            fs.writeFileSync(jsonPathSaldo,JSON.stringify(saldosCadastrados,null,2));
            return res.send('Saldo inserido com sucesso');
        }
    }
    // Usuário não encontrado
    return res.status(409).send(`Um erro ocorreu ao inserir saldo.`);

})

function verificaToken(req,res,next) {

    const authHeaders = req.headers['authorization'];
    
    const token = authHeaders && authHeaders.split(' ')[1]
    //Bearer token

    if(token == null) return res.status(401).send('Acesso Negado');

    jwt.verify(token, process.env.TOKEN, (err) => {
        if(err) return res.status(403).send('Token Inválido/Expirado');
        next();
    })

}