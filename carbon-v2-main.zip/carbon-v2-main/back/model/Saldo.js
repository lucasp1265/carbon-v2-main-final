class Saldo {

    constructor(email,saldo) {
        this.email = email;
        this.saldo = saldo;
    }
  }
  
  module.exports = Saldo;