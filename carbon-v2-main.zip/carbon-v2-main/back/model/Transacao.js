class Transacao {

    constructor(emailEnvio, emailRecebe, token, quantidade) {
        this.token = token;
        this.emailEnvio = emailEnvio;
        this.emailRecebe = emailRecebe;
        this.quantidade = quantidade;   
    }
  }
  
module.exports = Transacao;